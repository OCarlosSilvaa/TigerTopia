/*
 * Tiger 2D – configuration.
 * Everything that depends on the supplied art lives here, so new animations
 * (idle, run, …) or a new background can be added without touching the engine.
 */
(function (G) {
  'use strict';

  G.CONFIG = {
    background: {
      src: 'assets/background/jungle.jpg',
      width: 1672,            // native size of the supplied image
      height: 941
    },

    // Where the tiger's paws touch the ground, as a fraction of screen height.
    // 0.825 sits on the dirt path of the supplied jungle illustration.
    groundY: 0.825,

    // Tiger sprite height as a fraction of screen height (clamped on narrow screens).
    tigerHeightFrac: 0.30,

    // Animations. Each one is a numbered frame sequence in assets/tiger/<name>/.
    animations: {
      walk: {
        dir: 'assets/tiger/walk/',
        file: 'walk_{n}.webp',   // {n} -> zero padded frame number, 1-based
        pad: 3,
        count: 30,               // frames 001 … 030, played in numerical order
        frameW: 1030,            // size of each (cropped) frame in pixels
        frameH: 459,
        baselineY: 448,          // y of the planted paws inside a frame
        facing: 1,               // 1 = frames drawn facing right
        fps: 10,                 // playback rate at full walking speed
        // Ground travelled by a planted paw between two frames (sprite px).
        // Measured on the supplied frames; keeps the paws from "skating".
        strideShift: 94.5,
        // 1-based frames with several paws on the ground: the tiger comes to
        // rest on one of these when STOP is pressed.
        restFrames: [3, 4, 8, 9, 13, 18, 22, 23, 27]
      },

      // Sit down once (frames 1-11), then loop the seated tiger moving
      // head / paw / tail (frames 12-30). Played in reverse to stand up.
      sit: {
        dir: 'assets/tiger/sit/',
        file: 'sit_{n}.webp',
        pad: 3,
        count: 30,
        frameW: 1040,
        frameH: 540,
        baselineY: 529,
        facing: 1,
        fps: 8,
        introFrames: 11,         // frames 1..11 = sitting down (played once)
        riseSpeed: 1.3,          // standing up is a bit faster than sitting down
        fadeTime: 0.18           // cross-fade between walk and sit poses (s)
      },

      // Meat drops, the tiger eats and licks its mouth (30 frames, played once).
      feed: {
        dir: 'assets/tiger/feed/',
        file: 'feed_{n}.webp',
        pad: 3,
        count: 30,
        frameW: 1032,
        frameH: 630,
        baselineY: 583,
        facing: 1,
        fps: 8,
        oneShot: true            // plays once, then the tiger sits again
      },

      // Crouch, pounce and claw swipe with dust (34 frames, played once).
      attack: {
        dir: 'assets/tiger/attack/',
        file: 'attack_{n}.webp',
        pad: 3,
        count: 34,
        frameW: 1234,
        frameH: 603,
        baselineY: 591,
        anchorX: 515,            // sprite x that sits at the screen centre (the pounce reaches forward)
        shadowRx: 371,           // ground shadow radius, kept like the other poses
        facing: 1,
        fps: 12,
        oneShot: true
      }
      // run: { … }   <- future animations go here
    },

    // Movement feel (seconds)
    accelTime: 0.35,   // 0 -> full speed
    turnTime: 0.20     // full speed -> 0 when reversing direction
  };
})(window.TigerGame = window.TigerGame || {});
