/* Asset loading: background image + numbered animation frames. */
(function (G) {
  'use strict';

  function loadImage(src) {
    return new Promise(function (resolve, reject) {
      var img = new Image();
      img.onload = function () {
        // decode ahead of time so the first draw never stutters
        (img.decode ? img.decode().catch(function () {}) : Promise.resolve()).then(function () { resolve(img); });
      };
      img.onerror = function () { reject(new Error('Não foi possível carregar: ' + src)); };
      img.src = src;
    });
  }

  function pad(n, width) {
    var s = String(n);
    while (s.length < width) s = '0' + s;
    return s;
  }

  function frameUrl(def, i) {
    return def.dir + def.file.replace('{n}', pad(i, def.pad));
  }

  // Loads everything and resolves { background, animations: { name: [Image…] } }.
  G.loadAssets = function (config, onProgress) {
    var jobs = [];
    var total = 1, done = 0;
    Object.keys(config.animations).forEach(function (k) { total += config.animations[k].count; });
    function tick() { done++; if (onProgress) onProgress(done / total); }

    var result = { background: null, animations: {} };

    jobs.push(loadImage(config.background.src).then(function (img) { result.background = img; tick(); }));

    Object.keys(config.animations).forEach(function (name) {
      var def = config.animations[name];
      var frames = new Array(def.count);
      result.animations[name] = frames;
      for (var i = 1; i <= def.count; i++) {
        (function (idx) {
          jobs.push(loadImage(frameUrl(def, idx)).then(function (img) { frames[idx - 1] = img; tick(); }));
        })(i);
      }
    });

    return Promise.all(jobs).then(function () { return result; });
  };
})(window.TigerGame = window.TigerGame || {});
