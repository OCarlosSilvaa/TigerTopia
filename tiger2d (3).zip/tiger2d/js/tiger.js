/*
 * Tiger: movement state + frame selection.
 *
 * Modes
 *   walk : distance-driven walk cycle (frames advance with the ground, so the
 *          paws stay planted). STOP brakes onto a rest pose.
 *   sit  : plays the "sit down" frames once, then loops the seated idle.
 *   rise : plays the "sit down" frames backwards, then walking (or feeding) resumes.
 *   action : a one-shot animation ('feed' or 'attack'); afterwards the tiger
 *          sits, or walks if a walk command was pressed meanwhile.
 *
 * Switching between animations cross-fades the old pose into the new one.
 */
(function (G) {
  'use strict';

  function mod(a, n) { return ((a % n) + n) % n; }

  function Tiger(cfg) {
    this.cfg = cfg;
    this.walkDef = cfg.animations.walk;
    this.sitDef = cfg.animations.sit;
    this.apos = 0;            // position in the running action (frames)
    this.queued = null;       // command pressed during an action: 'left' | 'right' | 'stop'
    this.n = this.walkDef.count;
    this.accel = 1 / cfg.accelTime;
    this.turnDecel = 1 / cfg.turnTime;
    this.rest = {};
    this.walkDef.restFrames.forEach(function (f) { this.rest[f - 1] = true; }, this);

    this.mode = 'walk';
    this.command = 'right';   // 'left' | 'right' | 'stop' | an action name
    this.u = 1;               // signed walking velocity, -1 … 1
    this.facing = 1;          // 1 = right, -1 = left
    this.phase = 0;           // unwrapped walk frame position
    this.brake = null;
    this.pos = 0;             // position in the sit timeline (frames)
    this.fade = null;         // { anim, frame, facing, t, dur }
  }

  Tiger.prototype.walk = function (dir) {
    if (this.mode === 'action') { this.queued = dir < 0 ? 'left' : 'right'; return; }
    this.command = dir < 0 ? 'left' : 'right';
    this.brake = null;
    if (this.mode === 'sit') this._enterRise();
  };

  // One-shot action ('feed' | 'attack'): stop walking, stand up if sitting, then play it.
  Tiger.prototype.act = function (name) {
    if (this.mode === 'action') return;
    this.command = name;
    this.brake = null;
    if (this.mode === 'sit') this._enterRise();
  };

  Tiger.prototype.stop = function () {
    if (this.mode === 'action') { this.queued = 'stop'; return; }
    this.command = 'stop';
    this.brake = null;
    if (this.mode === 'rise') this.mode = 'sit';       // changed our mind: sit again
  };

  // ---- cross-fade helpers --------------------------------------------------
  Tiger.prototype._startFade = function (prev) {
    this.fade = { anim: prev.anim, frame: prev.frame, facing: prev.facing, t: 0, dur: this.sitDef.fadeTime };
  };

  Tiger.prototype._enterSit = function () {
    var prev = this.current();
    this.mode = 'sit';
    this.pos = 0;
    this.u = 0;
    this._startFade(prev);
  };

  Tiger.prototype._enterRise = function () {
    var prev = this.current();
    var intro = this.sitDef.introFrames;
    this.mode = 'rise';
    if (this.pos >= intro) {                 // was in the idle loop: start from the end of the sit-down
      this.pos = intro - 0.01;
      this._startFade(prev);
    }
  };

  Tiger.prototype._enterAction = function (name) {
    var prev = this.current();
    this.mode = 'action';
    this.action = name;
    this.apos = 0;
    this.u = 0;
    this.queued = null;
    this._startFade(prev);
  };

  Tiger.prototype._endAction = function () {
    var q = this.queued;
    this.queued = null;
    if (q === 'left' || q === 'right') {
      this.command = q;
      this.facing = q === 'left' ? -1 : 1;
      this._enterWalk();
    } else {
      this.command = 'stop';
      this._enterSit();
    }
  };

  Tiger.prototype._enterWalk = function () {
    var prev = this.current();
    this.mode = 'walk';
    this.u = 0;
    this.phase = (this.walkDef.restFrames[1] || 1) - 1;    // a standing-like walk frame
    this._startFade(prev);
  };

  // Next rest-pose frame we can reach after coasting a little.
  Tiger.prototype._planBrake = function () {
    var speed = Math.abs(this.u) * this.walkDef.fps;
    if (speed < 1.5) { this.u = 0; return; }       // already (almost) still: settle at once
    var k = Math.ceil(this.phase + speed * 0.30);
    var guard = 0;
    while (!this.rest[mod(k, this.n)] && guard++ < this.n) k++;
    var dist = Math.max(k - this.phase, 0.5);
    this.brake = { target: k, decel: (speed * speed) / (2 * dist), dir: Math.sign(this.u) };
  };

  /**
   * Advances the simulation.
   * @returns {number} signed ground distance travelled, in walk frames.
   */
  Tiger.prototype.update = function (dt) {
    if (this.fade) {
      this.fade.t += dt;
      if (this.fade.t >= this.fade.dur) this.fade = null;
    }
    if (this.mode === 'sit') { this._updateSit(dt); return 0; }
    if (this.mode === 'rise') { this._updateRise(dt); return 0; }
    if (this.mode === 'action') { this._updateAction(dt); return 0; }
    return this._updateWalk(dt);
  };

  Tiger.prototype._updateSit = function (dt) {
    this.pos += this.sitDef.fps * dt;
    var total = this.sitDef.count - this.sitDef.introFrames;
    var intro = this.sitDef.introFrames;
    if (this.pos > intro + total * 1000) this.pos = intro + mod(this.pos - intro, total);   // keep numbers small
  };

  Tiger.prototype._updateRise = function (dt) {
    this.pos -= this.sitDef.fps * this.sitDef.riseSpeed * dt;
    if (this.pos <= 0) {
      this.pos = 0;
      if (this._isAction(this.command)) this._enterAction(this.command); else this._enterWalk();
    }
  };

  Tiger.prototype._isAction = function (c) {
    var d = this.cfg.animations[c];
    return !!d && d.oneShot === true;
  };

  Tiger.prototype._updateAction = function (dt) {
    var def = this.cfg.animations[this.action];
    this.apos += def.fps * dt;
    if (this.apos >= def.count) this._endAction();
  };

  Tiger.prototype._updateWalk = function (dt) {
    var fps = this.walkDef.fps;
    var travelled = 0;

    if (this.command === 'stop' || this._isAction(this.command)) {
      if (this.u !== 0) {
        if (!this.brake) this._planBrake();
        if (this.brake) {
          var b = this.brake;
          var s0 = Math.abs(this.u) * fps;
          var s1 = Math.max(0, s0 - b.decel * dt);
          var adv = (s0 + s1) * 0.5 * dt;
          if (s1 <= 0 || this.phase + adv >= b.target) {
            adv = Math.max(0, b.target - this.phase);
            this.phase = b.target;
            this.u = 0;
            this.brake = null;
          } else {
            this.phase += adv;
            this.u = b.dir * s1 / fps;
          }
          travelled = b.dir * adv;
        }
      }
      if (this.u === 0) {                              // came to rest
        if (this._isAction(this.command)) this._enterAction(this.command); else this._enterSit();
      }
      return travelled;
    }

    var want = this.command === 'right' ? 1 : -1;
    var u0 = this.u, u1;
    if (Math.sign(u0) !== 0 && Math.sign(u0) !== want) {
      u1 = u0 + want * this.turnDecel * dt;
      if (Math.sign(u1) === want || u1 === 0) { u1 = 0; this.facing = want; }
    } else {
      if (u0 === 0) this.facing = want;
      u1 = u0 + want * this.accel * dt;
      u1 = Math.max(-1, Math.min(1, u1));
    }
    var adv2 = (Math.abs(u0) + Math.abs(u1)) * 0.5 * fps * dt;
    this.phase += adv2;
    this.u = u1;
    travelled = Math.sign(u0 + u1 || u1 || want) * adv2;
    if (Math.abs(u1) > 0.02) this.facing = Math.sign(u1);
    return travelled;
  };

  // The pose currently shown: { anim, frame (0-based), facing }.
  Tiger.prototype.current = function () {
    if (this.mode === 'walk') {
      return { anim: 'walk', frame: mod(Math.floor(this.phase + 1e-6), this.n), facing: this.facing };
    }
    if (this.mode === 'action') {
      var ad = this.cfg.animations[this.action];
      return { anim: this.action, frame: Math.min(Math.floor(this.apos), ad.count - 1), facing: this.facing };
    }
    var intro = this.sitDef.introFrames;
    var total = this.sitDef.count - intro;
    var f;
    if (this.pos < intro) f = Math.max(0, Math.floor(this.pos));
    else f = intro + Math.floor(mod(this.pos - intro, total));
    return { anim: 'sit', frame: f, facing: this.facing };
  };

  // Poses to draw, back to front: the cross-fading old pose goes on top.
  Tiger.prototype.layers = function () {
    var out = [Object.assign({ alpha: 1 }, this.current())];
    if (this.fade) {
      var a = 1 - this.fade.t / this.fade.dur;
      out.push({ anim: this.fade.anim, frame: this.fade.frame, facing: this.fade.facing, alpha: Math.max(0, a) });
    }
    return out;
  };

  G.Tiger = Tiger;
})(window.TigerGame = window.TigerGame || {});
