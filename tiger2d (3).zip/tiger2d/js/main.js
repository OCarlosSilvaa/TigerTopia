/* Bootstraps the game: loading, input, main loop. */
(function (G) {
  'use strict';

  var CFG = G.CONFIG;
  var canvas = document.getElementById('game');
  var loading = document.getElementById('loading');
  var buttons = {
    left: document.getElementById('btn-left'),
    stop: document.getElementById('btn-stop'),
    right: document.getElementById('btn-right'),
    feed: document.getElementById('btn-feed'),
    attack: document.getElementById('btn-attack')
  };

  G.loadAssets(CFG, function (p) {
    loading.textContent = 'Carregando a selva… ' + Math.round(p * 100) + '%';
  }).then(start).catch(function (err) {
    loading.className = 'error';
    loading.textContent = err.message + ' — abra o jogo a partir da pasta completa (index.html + assets/).';
    console.error(err);
  });

  function start(assets) {
    var walkDef = CFG.animations.walk;     // reference animation for scale and stride
    var world = new G.World(canvas, assets.background, CFG);
    var tiger = new G.Tiger(CFG);

    function resize() { world.resize(); }
    window.addEventListener('resize', resize);
    window.addEventListener('orientationchange', resize);
    resize();

    // ---- input ---------------------------------------------------------
    function setCommand(cmd) {
      // an action already running cannot be restarted: don't light up the button
      if ((cmd === 'feed' || cmd === 'attack') && tiger.mode === 'action') return;
      if (cmd === 'left') tiger.walk(-1);
      else if (cmd === 'right') tiger.walk(1);
      else if (cmd === 'feed' || cmd === 'attack') tiger.act(cmd);
      else tiger.stop();
      highlight(cmd);
    }

    function highlight(cmd) {
      Object.keys(buttons).forEach(function (k) {
        buttons[k].classList.toggle('active', k === cmd);
        buttons[k].setAttribute('aria-pressed', k === cmd ? 'true' : 'false');
      });
    }

    Object.keys(buttons).forEach(function (k) {
      buttons[k].addEventListener('click', function (e) {
        setCommand(k);
        // keep focus off the buttons so Space/Arrows always reach the keyboard handler
        if (e.detail > 0) buttons[k].blur();
      });
    });

    var KEYS = { ArrowLeft: 'left', ArrowRight: 'right', ' ': 'stop', Spacebar: 'stop', f: 'feed', F: 'feed', a: 'attack', A: 'attack' };
    window.addEventListener('keydown', function (e) {
      var cmd = KEYS[e.key];
      if (!cmd) return;
      e.preventDefault();
      if (!e.repeat) setCommand(cmd);
    });
    window.addEventListener('keyup', function (e) {
      if (KEYS[e.key]) e.preventDefault();   // stops Space from "clicking" a focused button
    });

    // ---- main loop -----------------------------------------------------
    var last = performance.now();
    var shownCmd = 'right';
    function frame(now) {
      var dt = Math.min((now - last) / 1000, 0.05);
      last = now;

      var travelledFrames = tiger.update(dt);
      if (tiger.command !== shownCmd) { shownCmd = tiger.command; highlight(shownCmd); }   // e.g. feeding ended -> sits
      world.scroll(travelledFrames * world.strideInBgPx(walkDef));

      world.drawBackground();
      var k = world.tigerScale(walkDef);
      var layers = tiger.layers();
      for (var i = 0; i < layers.length; i++) {
        var L = layers[i];
        world.drawTiger(assets.animations[L.anim][L.frame], CFG.animations[L.anim], L.facing, k, L.alpha, i === 0);
      }

      requestAnimationFrame(frame);
    }
    document.addEventListener('visibilitychange', function () { last = performance.now(); });

    setCommand('right');                 // starts walking right straight away
    requestAnimationFrame(function (t) {
      last = t;
      frame(t);
      loading.classList.add('done');
    });

    // debug / future hooks
    G.game = { world: world, tiger: tiger, setCommand: setCommand };
  }
})(window.TigerGame = window.TigerGame || {});
