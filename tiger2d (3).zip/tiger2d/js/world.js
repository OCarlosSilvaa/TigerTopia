/*
 * World: draws the supplied jungle illustration as an endless side-scrolling
 * background, plus the tiger on top of it.
 *
 * The image is never stretched: it is scaled uniformly to the screen height.
 * To repeat seamlessly, copies are laid side by side alternating normal and
 * mirrored, so every seam joins pixel-identical edges.
 */
(function (G) {
  'use strict';

  function World(canvas, bgImage, config) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.bg = bgImage;
    this.cfg = config;
    this.camX = config.background.width / 2;   // camera centre, in native background px
    this.W = 0; this.H = 0;                    // canvas size in device pixels
    this.sb = 1;                               // background scale (native -> device px)
  }

  World.prototype.resize = function () {
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var w = Math.max(1, Math.round(this.canvas.clientWidth * dpr));
    var h = Math.max(1, Math.round(this.canvas.clientHeight * dpr));
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
    }
    this.W = w; this.H = h;
    this.sb = h / this.cfg.background.height;
    this.ctx.imageSmoothingEnabled = true;
    this.ctx.imageSmoothingQuality = 'high';
  };

  // Tiger sprite scale (device px per sprite px) for an animation definition.
  World.prototype.tigerScale = function (def) {
    var byHeight = this.cfg.tigerHeightFrac * this.H;
    var byWidth = 0.92 * this.W * (def.frameH / def.frameW);   // never wider than the screen
    return Math.min(byHeight, byWidth) / def.frameH;
  };

  // Ground covered by one animation frame, in native background px.
  World.prototype.strideInBgPx = function (def) {
    return def.strideShift * this.tigerScale(def) / this.sb;
  };

  World.prototype.scroll = function (bgPx) { this.camX += bgPx; };

  World.prototype.drawBackground = function () {
    var ctx = this.ctx, W = this.W, H = this.H;
    var bw = this.cfg.background.width * this.sb;        // one tile, device px
    var camPx = this.camX * this.sb;
    var left = camPx - W / 2;
    var first = Math.floor(left / bw);
    var last = Math.floor((left + W) / bw);
    for (var i = first; i <= last; i++) {
      var x0 = Math.round(i * bw - left);
      var x1 = Math.round((i + 1) * bw - left);
      var w = x1 - x0;
      if (w <= 0) continue;
      if (((i % 2) + 2) % 2 === 0) {
        ctx.drawImage(this.bg, x0, 0, w, H);
      } else {                                           // mirrored copy
        ctx.save();
        ctx.translate(x1, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(this.bg, 0, 0, w, H);
        ctx.restore();
      }
    }
  };

  // Draws one tiger pose. `k` is the shared sprite scale (from the walk
  // animation), so every animation keeps the same size and paws on the ground.
  World.prototype.drawTiger = function (frameImg, def, facing, k, alpha, shadow) {
    var ctx = this.ctx;
    var sw = def.frameW * k, sh = def.frameH * k;
    var cx = this.W / 2;
    var groundY = Math.round(this.cfg.groundY * this.H);
    var top = Math.round(groundY - def.baselineY * k);

    if (shadow) {
      // soft contact shadow so the tiger sits on the path
      var rx = (def.shadowRx !== undefined ? def.shadowRx * k : sw * 0.36), ry = Math.max(4, sh * 0.045);
      ctx.save();
      ctx.translate(cx, groundY + ry * 0.15);
      ctx.scale(1, ry / rx);
      var g = ctx.createRadialGradient(0, 0, 0, 0, 0, rx);
      g.addColorStop(0, 'rgba(15,12,5,0.38)');
      g.addColorStop(0.6, 'rgba(15,12,5,0.18)');
      g.addColorStop(1, 'rgba(15,12,5,0)');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(0, 0, rx, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    }

    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.translate(cx, 0);
    if (facing * def.facing < 0) ctx.scale(-1, 1);
    var ax = (def.anchorX !== undefined ? def.anchorX * k : sw / 2);
    ctx.drawImage(frameImg, Math.round(-ax), top, Math.round(sw), Math.round(sh));
    ctx.restore();
  };

  G.World = World;
})(window.TigerGame = window.TigerGame || {});
